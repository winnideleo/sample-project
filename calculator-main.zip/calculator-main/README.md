Calculator
==========

[![Maven Central](https://img.shields.io/maven-central/v/com.github.javadev/calculator?style=flat-square)](https://central.sonatype.com/artifact/com.github.javadev/calculator/1.2)
[![Java CI](https://github.com/javadev/calculator/actions/workflows/maven.yml/badge.svg?branch=master)](https://github.com/javadev/calculator/actions/workflows/maven.yml)

The java/swing, javascript, android calculator

[![Screen short](calc.png)](https://github.com/javadev/calculator)
[![Screen short](calc2.png)](http://javadev.github.io/calculator)
